const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const db = new sqlite3.Database("./User.db");

app.use(express.json());

app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);

app.post("/api/save", async (req, res) => {
  console.log(req.body);
  new Promise(async (resolve, reject) => {
    db.run(
      `UPDATE User SET Code = ${req.body.code} WHERE ChatID = ${Number(
        req.body.chatid
    )}`
    );
  });

  return res.redirect("https://t.me/uTgAutoBot?start=code");
});

app.use("/", express.static(path.join(__dirname, ".", "index.html")));

app.get("*", (req, res) => {
  res.sendFile(path.resolve(__dirname, ".", "index.html"));
});

function bootstrap() {
  try {
    app.listen(8080, () => console.log("app started"));
  } catch (e) {
    console.error(e);
  }
}

bootstrap();
